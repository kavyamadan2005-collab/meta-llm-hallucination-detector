"""Pydantic schemas package."""
